/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7e5eb42b'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "registerSW.js",
    "revision": "402b66900e731ca748771b6fc5e7a068"
  }, {
    "url": "pwa-512x512.png",
    "revision": "1af0fa1d34bc33a60b81876edec3f6ae"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f1b6ab1a14370937de86a33f33de9bc8"
  }, {
    "url": "index.html",
    "revision": "53ceb1a2158d13a6a7f94951af08d5b4"
  }, {
    "url": "icon.svg",
    "revision": "52984b6ad090df79ecfed6c611439c69"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "9be0b70415f8f0b832be0af3cb545510"
  }, {
    "url": "assets/index-D8z95wic.css",
    "revision": null
  }, {
    "url": "assets/index-C1LQzdI9.js",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "9be0b70415f8f0b832be0af3cb545510"
  }, {
    "url": "icon.svg",
    "revision": "52984b6ad090df79ecfed6c611439c69"
  }, {
    "url": "pwa-192x192.png",
    "revision": "f1b6ab1a14370937de86a33f33de9bc8"
  }, {
    "url": "pwa-512x512.png",
    "revision": "1af0fa1d34bc33a60b81876edec3f6ae"
  }, {
    "url": "manifest.webmanifest",
    "revision": "1c0560bf5cce24ac8d0e39b50a58d34c"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("index.html")));

}));
